package com.example.dechickmanagementstore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class forget extends AppCompatActivity {
    Button submit_email, submit_phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget);

        submit_email = findViewById(R.id.submit_email);
        submit_phone = findViewById(R.id.submit_phone);


        submit_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(forget.this, "Restore password has been sent to email", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(forget.this, MainActivity.class);
                startActivity(intent);
            }
        });

        submit_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(forget.this, "Restore password has been sent to phone", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(forget.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
